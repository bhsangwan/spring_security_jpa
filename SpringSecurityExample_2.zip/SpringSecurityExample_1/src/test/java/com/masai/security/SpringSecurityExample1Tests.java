package com.masai.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityExample1Tests {

	@Test
	void contextLoads() {
	}

}
