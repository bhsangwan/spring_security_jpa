package com.masai.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.masai.security.entity.Employee;
import com.masai.security.entity.SecurityUser;
import com.masai.security.respository.EmployeeRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService{

	@Autowired
	EmployeeRepository repository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		//Login to fetch the Employee from database
		System.out.println("In loadUserByUSername");
		Employee employee = repository.findByUserName(username);
		if(employee != null)
			return new SecurityUser(employee);  //UserDetails object
		else
			throw new UsernameNotFoundException("User Does Not Exist..!");
	}

}
