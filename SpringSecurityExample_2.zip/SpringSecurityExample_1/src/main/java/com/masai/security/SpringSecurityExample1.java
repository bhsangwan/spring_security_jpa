package com.masai.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityExample1 {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityExample1.class, args);
	}

}
